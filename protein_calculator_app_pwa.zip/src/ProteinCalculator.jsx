// simplified for zip
export default function ProteinCalculator() { return <div>App here</div>; }